<?php
session_start();
header('Content-Type: application/json');

// Enable error reporting during development
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawData = file_get_contents('php://input');
    $data = json_decode($rawData, true);

    if (json_last_error() === JSON_ERROR_NONE) {
        $vendorID = $data['vendorID'];
        $pickup = $data['pickup'];
        $dropOff = $data['dropOff'];
        $pickUpDateTime = $data['pickUpDateTime'];
        $dropOffDateTime = $data['dropOffDateTime'];
        $carCategory = $data['carCategory'];

        function makeApiCall($vendorID, $pickup, $dropOff, $pickUpDateTime, $dropOffDateTime)
        {
            $xmlRequest = "
        <?xml version=\"1.0\" encoding=\"UTF-8\" ?>
        <OTA_VehAvailRateRQ xmlns=\"http://www.opentravel.org/OTA/2003/05\" Version=\"1.008\">
            <POS>
                <Source ISOCountry=\"AU\" AgentDutyCode=\"T17R16L5D11\">
                    <RequestorID Type=\"4\" ID=\"X975\">
                        <CompanyName Code=\"CP\" CodeContext=\"4PH5\"></CompanyName>
                    </RequestorID>
                </Source>
                <Source>
                    <RequestorID Type=\"8\" ID=\"$vendorID\"/>
                </Source>
            </POS>
            <VehAvailRQCore Status=\"Available\">
                <VehRentalCore PickUpDateTime=\"$pickUpDateTime\" ReturnDateTime=\"$dropOffDateTime\">
                    <PickUpLocation LocationCode=\"$pickup\" CodeContext=\"IATA\"/>
                    <ReturnLocation LocationCode=\"$dropOff\" CodeContext=\"IATA\"/>
                </VehRentalCore>
            </VehAvailRQCore>
        </OTA_VehAvailRateRQ>
        ";

            $apiUrl = 'https://vv.xqual.hertz.com/DirectLinkWEB/handlers/DirectLinkHandler?id=ota2007a';
            $ch = curl_init($apiUrl);

            // Set cURL options
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/xml',
                'Content-Length: ' . strlen($xmlRequest)
            ]);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlRequest);

            // Execute the cURL request and capture the response
            $response = curl_exec($ch);

            // Check for errors
            if (curl_errno($ch)) {
                echo 'cURL Error: ' . curl_error($ch);
            }

            curl_close($ch);

            return $response;
        }
        $_SESSION['QuoteResponse'] = $response;
        $xmlres = new SimpleXMLElement($response);

        // Function to convert SimpleXMLElement to array
        function xmlToArray($xmlObject)
        {
            return json_decode(json_encode($xmlObject), true);
        }

        // Convert the SimpleXMLElement to array
        $xmlArray = xmlToArray($xmlres);

        function filterResultsByReference($results, $referenceType, $referenceID)
        {
            $filteredResults = [];

            // Traverse through the array to locate the vehicles and filter by Reference Type and ID
            foreach ($results['VehAvailRSCore']['VehVendorAvails']['VehVendorAvail']['VehAvails']['VehAvail'] as $vehAvail) {
                if (isset($vehAvail['VehAvailCore']['Reference']['@attributes'])) {
                    $ref = $vehAvail['VehAvailCore']['Reference']['@attributes'];
                    if ($ref['Type'] == $referenceType && $ref['ID'] == $referenceID) {
                        $filteredResults[] = $vehAvail;
                    }
                }
            }

            return $filteredResults;
        }

        $referenceType = "16";
        $referenceID = $reference;  // Use the ID you want to filter by
        $filteredResults = filterResultsByReference($xmlArray, $referenceType, $referenceID);
        $_SESSION['quoteFilteredResults'] = $filteredResults;
        $code = $filteredResults[0]['VehAvailCore']['Vehicle']['@attributes']['Code'];
        // echo $code;
        if (!empty($filteredResults)) {
            $vehicle = $filteredResults[0]; // Assuming we want the first matching result

            // Vehicle details
            $name = $vehicle['VehAvailCore']['Vehicle']['VehMakeModel']['@attributes']['Name'];
            $transmission = $vehicle['VehAvailCore']['Vehicle']['@attributes']['TransmissionType'];
            $passengers = $vehicle['VehAvailCore']['Vehicle']['@attributes']['PassengerQuantity'];
            $luggage = $vehicle['VehAvailCore']['Vehicle']['@attributes']['BaggageQuantity'];
            $rate = $vehicle['VehAvailCore']['TotalCharge']['@attributes']['RateTotalAmount'];
            $final = number_format(calculatePercentage($markUp, $rate), 2);
            $currency = $vehicle['VehAvailCore']['TotalCharge']['@attributes']['CurrencyCode'];
            $image = $vehicle['VehAvailCore']['Vehicle']['PictureURL'];
            if ($vdNo == "ZE") {
                $vendorLogo = "images/hertz.png";
            } elseif ($vdNo == "ZT") {
                $vendorLogo = "./images/thrifty.png";
            } else {
                $vendorLogo = "images/DOLLARRet.png";
            }
        } else {
            echo "No matching vehicle found.";
            exit;
        }
        $response = makeApiCall($vendorID, $pickup, $dropOff, $pickUpDateTime, $dropOffDateTime);
        $rate = 0;
        $currency = 'USD';

        // if (isset($response['response']) && !empty($response['response'])) {
        //     $xml = simplexml_load_string($response['response']);
        //     if ($xml !== false && isset($xml->serviceResponse->reservation->quote)) {
        //         $rate = (float) $xml->serviceResponse->reservation->quote['basePrice'];
        //         $currency = (string) $xml->serviceResponse->reservation->quote['currency'];
        //     }
        // }
        if ($_SESSION['quoteFilteredResults'] && $_SESSION['QuoteResponse']) {
            echo json_encode("success session set");
        }
        $resData = [
            'name' => $name,
            'transmission' => $transmission,
            'passengers' => $passengers,
            'luggage' => $luggage,
            'rate' => $final,
            'currency' => $currency,
            'image' => $image,
            'vendorLogo' => $vendorLogo
        ];
        echo json_encode($resData);
    } else {
        echo json_encode(['error' => 'Invalid JSON payload']);
    }
} else {
    echo json_encode(['error' => 'Invalid request method']);
}

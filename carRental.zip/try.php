<?php 
session_start();
var_dump("Quoter Response",$_SESSION['QuoteResponse']);